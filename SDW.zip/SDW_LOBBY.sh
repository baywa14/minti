echo "WAIT..."
echo "10 SEC ONLY"
echo "YOU WILL AUTOMATICLY"
echo "GO BACK IN PUBG"
echo "DONT FORGET TO USE\nMEMORY ANTIBAN IN LOBBY"
mv /data/data/com.tencent.ig/lib/libtprt.so /storage/emulated/0/Download/SDW/REAL_SDW-1
mv /data/data/com.tencent.ig/lib/libUE4.so /storage/emulated/0/Download/SDW/REAL_SDW-1
mv /data/data/com.tencent.ig/lib/libzlib.so /storage/emulated/0/Download/SDW/REAL_SDW-1
sleep 5
mv /storage/emulated/0/Download/SDW/FAKE_SDW-1/libzlib.so /data/data/com.tencent.ig/lib/libzlib.so
mv /storage/emulated/0/Download/SDW/FAKE_SDW-1/libUE4.so /data/data/com.tencent.ig/lib/libUE4.so
mv /storage/emulated/0/Download/SDW/FAKE_SDW-1/libtprt.so /data/data/com.tencent.ig/lib/libtprt.so
sleep 5
am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity
echo "DONE"
echo "CREATOR :- SADEWA